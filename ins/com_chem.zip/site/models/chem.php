<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.application.component.model');

class ChemModelChem extends JModel{
    function _getChemQuery(){

    }

    function grtChem(){

    }
}

